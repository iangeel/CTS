package ro.ase.exception;

public class OperationsException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OperationsException(String m) {
		super(m);
	}
}

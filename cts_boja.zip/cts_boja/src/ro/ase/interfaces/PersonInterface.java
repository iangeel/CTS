package ro.ase.interfaces;

public interface PersonInterface {
	int valitateAge(int age); 
}

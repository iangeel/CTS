
public class ExceptionNrCifre extends Exception{

}

public interface IProdus {
	boolean isOnSale();

	float getPrice();
}

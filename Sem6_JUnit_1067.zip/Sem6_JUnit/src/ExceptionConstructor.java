
public class ExceptionConstructor extends Exception{

}

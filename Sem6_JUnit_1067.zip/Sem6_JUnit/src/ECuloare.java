
public enum ECuloare {
	ROSU, VERDE, NEGRU, ALB
}

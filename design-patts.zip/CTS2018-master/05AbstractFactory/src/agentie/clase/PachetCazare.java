package agentie.clase;

public interface PachetCazare {
	void descriere();
}

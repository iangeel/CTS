package agentie.clase;

public class TransportCategoria1 implements PachetTransport {

	@Override
	public void descriere() {
		System.out.println("Ati ales transport categoria I");
	}

}

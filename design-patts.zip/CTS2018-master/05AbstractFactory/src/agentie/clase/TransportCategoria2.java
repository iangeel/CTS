package agentie.clase;

public class TransportCategoria2 implements PachetTransport {

	@Override
	public void descriere() {
		System.out.println("Ati ales transport categoria II");
	}

}

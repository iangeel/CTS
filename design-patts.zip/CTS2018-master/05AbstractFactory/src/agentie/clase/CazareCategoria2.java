package agentie.clase;

public class CazareCategoria2 implements PachetCazare {

	@Override
	public void descriere() {
		System.out.println("Ati ales o cazare categoria II");
	}

}

package v8_registry_of_singletons;

public interface PachetTuristic {
	void descriere();
}

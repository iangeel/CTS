package hotel.observer;

public interface Observer {
	void primesteSMS(String sms);
	void primesteEmail(String email);

}

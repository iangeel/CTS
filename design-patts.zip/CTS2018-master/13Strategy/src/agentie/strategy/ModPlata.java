package agentie.strategy;

public interface ModPlata {

	void plateste(String numeClient, double sumaPlatita);
}

package hotel.strategy;

public interface ModVerificare {
	void verificaActe(String nume);

}

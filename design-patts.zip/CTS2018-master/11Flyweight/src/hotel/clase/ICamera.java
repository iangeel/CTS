package hotel.clase;

public interface ICamera {

	void tiparire(Rezervare rezervare);
}

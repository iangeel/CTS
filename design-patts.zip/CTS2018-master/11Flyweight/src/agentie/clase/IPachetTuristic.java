package agentie.clase;

public interface IPachetTuristic {

	void descriePachet(Optionale optionale);
}

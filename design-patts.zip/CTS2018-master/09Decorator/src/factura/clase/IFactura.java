package factura.clase;

public interface IFactura {
	void printeazaFactura();
}

package agentie.clase;

public enum TipPachet {
	pachetCazare,
	pachetTransport,
	pachetCazareSiTransport
}

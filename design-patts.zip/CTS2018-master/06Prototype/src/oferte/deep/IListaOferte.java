package oferte.deep;

public interface IListaOferte {
	IListaOferte copiaza();
	void incarcaListaOferte();
}

package hotel.clase;

public interface IRezervare {
	void anulareRezervare();
}

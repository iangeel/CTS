package agentie.adapterobiecte.clase;

public interface PachetTuristic {
	void descriere();
	void rezervaPachet();
}

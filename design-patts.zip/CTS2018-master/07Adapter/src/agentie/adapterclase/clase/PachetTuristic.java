package agentie.adapterclase.clase;

public interface PachetTuristic {
	void descriere();
	void rezervaPachet();
}

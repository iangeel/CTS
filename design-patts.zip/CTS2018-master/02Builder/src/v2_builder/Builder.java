package v2_builder;

public interface Builder {
	PachetTransport build();
}

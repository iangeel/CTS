package agentie.clase;

public class PachetAllInclusive implements PachetTuristic {

	@Override
	public void descriere() {
		System.out.println("Pachet all inclusive");

	}

}

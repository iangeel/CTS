package testscategories;

public interface PerformanceTests {

}

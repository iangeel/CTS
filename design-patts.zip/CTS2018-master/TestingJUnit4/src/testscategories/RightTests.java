package testscategories;

public interface RightTests {

}

package testscategories;

public interface FastTest {

}

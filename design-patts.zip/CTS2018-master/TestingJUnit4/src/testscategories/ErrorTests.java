package testscategories;

public interface ErrorTests {

}

package testscategories;

public interface BounderyTests {

}

package testscategories;

public interface InverseTests {

}

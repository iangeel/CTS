package testscategories;

public interface CrossCheckTests {

}

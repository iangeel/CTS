package testscategories;

public interface SlowTest {

}

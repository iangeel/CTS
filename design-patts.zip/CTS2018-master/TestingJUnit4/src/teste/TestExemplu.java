package teste;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestExemplu {

	@Test
	public void test() {
		//fail("Not yet implemented");
	}

}

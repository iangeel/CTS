package agentie.clase;

public interface Command {
	void executa();
}

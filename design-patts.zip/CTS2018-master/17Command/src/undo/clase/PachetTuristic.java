package undo.clase;

public interface PachetTuristic {
	void vanzare();
	void rezerva();
	void anulareVanzare();
	void anulareRezervare();
}
